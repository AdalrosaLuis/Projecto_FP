	fun obterMenu():String {
		val menuCarteira = "#  Comando\n" +
				"1. Consultar\n" +
				"2. Adicionar\n" +
				"3. Editar\n" +
				"4. Liquidar\n" +
				"5. Guardar\n" +
				"9. Configuracoes\n" +
				"0. Sair\n"
			
		return menuCarteira
	}
	fun lerConfiguracoes(fileName: String, configuracoes:Array<String>):Boolean {
		return false
	}
	fun guardarConfiguracoes(fileName: String, liquidacoes:Array<String>) {
	
	}
	
	fun lerLiquidacoes(fileName: String,liquidacoes:Array<Double>):Boolean{
		
		return false
	}
	fun guardarLiquidacoes(fileName:String,liquidacoes:Array<Double>){
	
	}
	fun lerInvestimentos(fileName:String,investimentos:Array<Array<String>?>):Boolean{
		return false
		
	}
	fun consultarInvestimentos(investimentos: Array<Array<String>?>,
	                           configuracoes: Array<String>, liquidacoes: Array<Double>): String{
		return ""
		
	}
	fun adicionarInvestimento(investimentos: Array<Array<String>?>, nome: String,
	                          valorInvestido: Double, valorAtual: Double): String{
		return ""
	}
	fun editarInvestimento(investimentos: Array<Array<String>?>, nome: String, valor: Double): String{
		return ""
	}
	fun liquidarInvestimento(liquidacoes: Array<Double>, investimentos: Array<Array<String>?>, numero: Int): String{
		return ""
	}
	fun guardarInvestimentos(fileName:String, investimentos:Array<Array<String>?>) {
	
	}
	fun main() {
		var nome: String
		var moeda: String
		
		println(
			"#####################\n" +
					"### Investimentos ###\n" +
					"#####################\n"
		)
		
		while (true) {
			println("Por favor indique o seu nome:")
			nome = readln()
			
			println("Por favor indique a moeda da sua conta(€ ou $):")
			moeda = readln()
			
			val nomeCompleto = nome.split(" ")
			
			if (nomeCompleto.size != 2 || (moeda != "$" && moeda != "€")) {
				println(
					"Dados invalidos.\n" +
							"O nome completo deve ser definido por pelomenos " +
							"um espaço vazio e pelo menos 4 caracteres.\n" +
							"A moeda deverá ser em $ ou €.\n"
				)
			}
			else {
				println(obterMenu())
			}
			print("Indica o que pretendes:\n ")
			val opcao = readln().toInt()
			
			when (opcao) {
				1 -> println("Consultar investimentos")
				2 -> println("Adicionar investimentos")
				3 -> println("Editar investimentos")
				4 -> println("Liquidar investimentos")
				5 -> println("investimentos guardados com sucesso.")
				0 -> println("Adeus e bons investimentos")
				else -> println("Opção invalida")
			}
		}
	}
		
	
	
	
